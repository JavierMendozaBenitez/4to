<?php
interface IBM
{
    public function Modificar() : bool;
    public static function Eliminar($id) : bool;
}
?>