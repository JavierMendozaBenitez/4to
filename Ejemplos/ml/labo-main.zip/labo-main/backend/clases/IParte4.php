<?php
//DECLARO UNA INTERFACE
interface IParte4
{
	function guardarEnArchivo():string;	
}

