<?php 
interface IBM {
    public function Modificar();
    public static function Eliminar($id);
}