<?php
//DECLARO UNA INTERFACE
interface IParte2
{
	function modificar():bool;	
	static function eliminar(int $id):bool;	
}

