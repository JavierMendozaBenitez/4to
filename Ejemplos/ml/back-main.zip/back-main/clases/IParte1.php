<?php
//DECLARO UNA INTERFACE
interface IParte1
{
	function agregar():bool;	
	static function traer():array;	
}

