<?php
//DECLARO UNA INTERFACE
interface IParte3
{
	function existe( array $neumaticosBD):bool;	
}

