<?php
require_once "./clases/neumaticoBD.php";
use LunaMilagros\NeumaticoBd;


NeumaticoBd::mostrarBorradosJSON();